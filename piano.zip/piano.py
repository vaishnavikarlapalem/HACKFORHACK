import pygame

# Initialize pygame
pygame.init()

# Set up the display
screen_width = 800
screen_height = 400
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Virtual Piano and Music Player")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (169, 169, 169)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

# Global state to switch between screens
current_screen = "menu"  # options: "menu", "piano", "music_player"

# Load piano key sounds (using mp3 files instead of wav)
keys = [
    {"note": "C", "file": "sounds/C.mp3","rect":  pygame.Rect(50, 100, 100, 200)},
    {"note": "D", "file": "sounds/D.mp3", "rect": pygame.Rect(150, 100, 100, 200)},
    {"note": "E", "file": "sounds/E.mp3", "rect": pygame.Rect(250, 100, 100, 200)},
    {"note": "F", "file": "sounds/F.mp3", "rect": pygame.Rect(350, 100, 100, 200)},
    {"note": "G", "file": "sounds/G.mp3", "rect": pygame.Rect(450, 100, 100, 200)},
    {"note": "A", "file": "sounds/A.mp3", "rect": pygame.Rect(550, 100, 100, 200)},
    {"note": "B", "file": "sounds/B.mp3", "rect": pygame.Rect(650, 100, 100, 200)},
]

# Load music files for the music player
music_files = [
    "sounds/song1.mp3",  # Replace with actual paths
    "sounds/song2.mp3",
    "sounds/song3.mp3",
    "sounds/song4.mp3",
    "sounds/song5.mp3",
]

# Load sound objects for the piano keys
for key in keys:
    try:
        key["sound"] = pygame.mixer.Sound(key["file"])
    except pygame.error as e:
        print(f"Error loading sound {key['file']}: {e}")

# Function to play the sound for a given key
def play_sound(sound):
    if sound:
        try:
            sound.play()
        except pygame.error as e:
            print(f"Error playing sound: {e}")

# Function to draw the menu screen
def draw_menu():
    screen.fill(WHITE)
    font = pygame.font.Font(None, 74)
    
    # Draw buttons
    pygame.draw.rect(screen, BLUE, (250, 100, 300, 100))  # Piano button
    pygame.draw.rect(screen, GREEN, (250, 250, 300, 100))  # Music Player button
    
    # Draw text on buttons
    piano_text = font.render("Piano", True, WHITE)
    music_player_text = font.render("Music Player", True, WHITE)
    screen.blit(piano_text, (330, 120))
    screen.blit(music_player_text, (280, 270))

# Function to draw the piano keys and back button
def draw_piano():
    screen.fill(WHITE)
    font = pygame.font.Font(None, 36)

    # Draw Back button
    pygame.draw.rect(screen, RED, (50, 50, 100, 50))  # Back button
    back_text = font.render("Back", True, WHITE)
    screen.blit(back_text, (70, 60))

    # Draw piano keys
    for key in keys:
        pygame.draw.rect(screen, BLACK, key["rect"])  # Draw piano key

    # Add a white rectangle overlay to represent the piano keys
    for i, key in enumerate(keys):
        if i % 2 == 0:  # Draw every second key in white for visual representation
            pygame.draw.rect(screen, WHITE, key["rect"])
    
# Function to draw the music player screen
def draw_music_player():
    screen.fill(WHITE)
    font = pygame.font.Font(None, 36)

    # Draw Back button
    pygame.draw.rect(screen, RED, (50, 50, 100, 50))  # Back button
    back_text = font.render("Back", True, WHITE)
    screen.blit(back_text, (70, 60))

    # Draw music buttons
    button_positions = [(200, 150), (200, 220), (200, 290), (400, 150), (400, 220)]
    for i, pos in enumerate(button_positions):
        pygame.draw.rect(screen, GRAY, (pos[0], pos[1], 150, 50))
        song_text = font.render(f"Song {i + 1}", True, BLACK)
        screen.blit(song_text, (pos[0] + 20, pos[1] + 10))

# Main loop
running = True
while running:
    if current_screen == "menu":
        draw_menu()  # Draw the menu screen
    elif current_screen == "piano":
        draw_piano()  # Draw the piano keys and Back button
    elif current_screen == "music_player":
        draw_music_player()  # Draw the music player and Back button

    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if current_screen == "menu":
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()

                # Check if Piano button is clicked
                if 250 <= pos[0] <= 550 and 100 <= pos[1] <= 200:
                    current_screen = "piano"
                
                # Check if Music Player button is clicked
                if 250 <= pos[0] <= 550 and 250 <= pos[1] <= 350:
                    current_screen = "music_player"

        if current_screen == "piano":
            if event.type == pygame.MOUSEBUTTONDOWN:
                # Check if Back button is clicked
                pos = pygame.mouse.get_pos()
                if 50 <= pos[0] <= 150 and 50 <= pos[1] <= 100:
                    current_screen = "menu"  # Go back to the menu

                # Play the sound for the corresponding key
                for key in keys:
                    if key["rect"].collidepoint(pos):
                        play_sound(key["sound"])

            if event.type == pygame.KEYDOWN:
                # Play piano notes with keyboard keys
                if event.key == pygame.K_c:
                    play_sound(keys[0]["sound"])
                if event.key == pygame.K_d:
                    play_sound(keys[1]["sound"])
                if event.key == pygame.K_e:
                    play_sound(keys[2]["sound"])
                if event.key == pygame.K_f:
                    play_sound(keys[3]["sound"])
                if event.key == pygame.K_g:
                    play_sound(keys[4]["sound"])
                if event.key == pygame.K_a:
                    play_sound(keys[5]["sound"])
                if event.key == pygame.K_b:
                    play_sound(keys[6]["sound"])

        if current_screen == "music_player":
            if event.type == pygame.MOUSEBUTTONDOWN:
                # Check if Back button is clicked
                pos = pygame.mouse.get_pos()
                if 50 <= pos[0] <= 150 and 50 <= pos[1] <= 100:
                    current_screen = "menu"  # Go back to the menu

                # Check if any song button is clicked
                button_positions = [(200, 150), (200, 220), (200, 290), (400, 150), (400, 220)]
                for i, pos in enumerate(button_positions):
                    if pos[0] <= pygame.mouse.get_pos()[0] <= pos[0] + 150 and       pos[1] <= pygame.mouse.get_pos()[1] <= pos[1] + 50:
                    #try:import pygame
                        try:
                            pygame.init()
                        except Exception as e:
                            print(f"An error occurred: {e}")

# Initialize pygame
pygame.init()

# Set up the display
screen_width = 800
screen_height = 400
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Virtual Piano and Music Player")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (169, 169, 169)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

# Global state to switch between screens
current_screen = "menu"  # options: "menu", "piano", "music_player"

# Load piano key sounds (using mp3 files instead of wav)
keys = [
    {"note": "C", "file": "sounds/C.mp3","rect":  pygame.Rect(50, 100, 100, 200)},
    {"note": "D", "file": "sounds/D.mp3", "rect": pygame.Rect(150, 100, 100, 200)},
    {"note": "E", "file": "sounds/E.mp3", "rect": pygame.Rect(250, 100, 100, 200)},
    {"note": "F", "file": "sounds/F.mp3", "rect": pygame.Rect(350, 100, 100, 200)},
    {"note": "G", "file": "sounds/G.mp3", "rect": pygame.Rect(450, 100, 100, 200)},
    {"note": "A", "file": "sounds/A.mp3", "rect": pygame.Rect(550, 100, 100, 200)},
    {"note": "B", "file": "sounds/B.mp3", "rect": pygame.Rect(650, 100, 100, 200)},
]

# Load music files for the music player
music_files = [
    "sounds/song1.mp3",  # Replace with actual paths
    "sounds/song2.mp3",
    "sounds/song3.mp3",
    "sounds/song4.mp3",
    "sounds/song5.mp3",
]

# Load sound objects for the piano keys
for key in keys:
    try:
        key["sound"] = pygame.mixer.Sound(key["file"])
    except pygame.error as e:
        print(f"Error loading sound {key['file']}: {e}")

# Function to play the sound for a given key
def play_sound(sound):
    if sound:
        try:
            sound.play()
        except pygame.error as e:
            print(f"Error playing sound: {e}")

# Function to draw the menu screen
def draw_menu():
    screen.fill(WHITE)
    font = pygame.font.Font(None, 74)
    
    # Draw buttons
    pygame.draw.rect(screen, BLUE, (250, 100, 300, 100))  # Piano button
    pygame.draw.rect(screen, GREEN, (250, 250, 300, 100))  # Music Player button
    
    # Draw text on buttons
    piano_text = font.render("Piano", True, WHITE)
    music_player_text = font.render("Music Player", True, WHITE)
    screen.blit(piano_text, (330, 120))
    screen.blit(music_player_text, (280, 270))

# Function to draw the piano keys and back button
def draw_piano():
    screen.fill(WHITE)
    font = pygame.font.Font(None, 36)

    # Draw Back button
    pygame.draw.rect(screen, RED, (50, 50, 100, 50))  # Back button
    back_text = font.render("Back", True, WHITE)
    screen.blit(back_text, (70, 60))

    # Draw piano keys
    for key in keys:
        pygame.draw.rect(screen, BLACK, key["rect"])  # Draw piano key

    # Add a white rectangle overlay to represent the piano keys
    for i, key in enumerate(keys):
        if i % 2 == 0:  # Draw every second key in white for visual representation
            pygame.draw.rect(screen, WHITE, key["rect"])
    
# Function to draw the music player screen
def draw_music_player():
    screen.fill(WHITE)
    font = pygame.font.Font(None, 36)

    # Draw Back button
    pygame.draw.rect(screen, RED, (50, 50, 100, 50))  # Back button
    back_text = font.render("Back", True, WHITE)
    screen.blit(back_text, (70, 60))

    # Draw music buttons
    button_positions = [(200, 150), (200, 220), (200, 290), (400, 150), (400, 220)]
    for i, pos in enumerate(button_positions):
        pygame.draw.rect(screen, GRAY, (pos[0], pos[1], 150, 50))
        song_text = font.render(f"Song {i + 1}", True, BLACK)
        screen.blit(song_text, (pos[0] + 20, pos[1] + 10))

# Main loop
running = True
while running:
    if current_screen == "menu":
        draw_menu()  # Draw the menu screen
    elif current_screen == "piano":
        draw_piano()  # Draw the piano keys and Back button
    elif current_screen == "music_player":
        draw_music_player()  # Draw the music player and Back button

    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if current_screen == "menu":
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()

                # Check if Piano button is clicked
                if 250 <= pos[0] <= 550 and 100 <= pos[1] <= 200:
                    current_screen = "piano"
                
                # Check if Music Player button is clicked
                if 250 <= pos[0] <= 550 and 250 <= pos[1] <= 350:
                    current_screen = "music_player"

        if current_screen == "piano":
            if event.type == pygame.MOUSEBUTTONDOWN:
                # Check if Back button is clicked
                pos = pygame.mouse.get_pos()
                if 50 <= pos[0] <= 150 and 50 <= pos[1] <= 100:
                    current_screen = "menu"  # Go back to the menu

                # Play the sound for the corresponding key
                for key in keys:
                    if key["rect"].collidepoint(pos):
                        play_sound(key["sound"])

            if event.type == pygame.KEYDOWN:
                # Play piano notes with keyboard keys
                if event.key == pygame.K_c:
                    play_sound(keys[0]["sound"])
                if event.key == pygame.K_d:
                    play_sound(keys[1]["sound"])
                if event.key == pygame.K_e:
                    play_sound(keys[2]["sound"])
                if event.key == pygame.K_f:
                    play_sound(keys[3]["sound"])
                if event.key == pygame.K_g:
                    play_sound(keys[4]["sound"])
                if event.key == pygame.K_a:
                    play_sound(keys[5]["sound"])
                if event.key == pygame.K_b:
                    play_sound(keys[6]["sound"])

        if current_screen == "music_player":
            if event.type == pygame.MOUSEBUTTONDOWN:
                # Check if Back button is clicked
                pos = pygame.mouse.get_pos()
                if 50 <= pos[0] <= 150 and 50 <= pos[1] <= 100:
                    current_screen = "menu"  # Go back to the menu

                # Check if any song button is clicked
                button_positions = [(200, 150), (200, 220), (200, 290), (400, 150), (400, 220)]
                for i, pos in enumerate(button_positions):
                    if pos[0] <= pygame.mouse.get_pos()[0] <= pos[0] + 150 and pos[1] <= pygame.mouse.get_pos()[1] <= pos[1] + 50:
                        try:
                            # Stop any currently playing sound before playing a new one
                            pygame.mixer.music.stop()
                            pygame.mixer.music.load(music_files[i])  # Load the selected song
                            pygame.mixer.music.play()  # Play the selected song
                        except pygame.error as e:
                            print(f"Error loading music file: {music_files[i]} - {e}")

    # Update the display
    pygame.display.update()

# Quit pygame
pygame.quit()

                            # Stop any currently playing sound before playing a new one
pygame.init()
pygame.mixer.music.stop()
pygame.mixer.music.load(music_files[i])  # Load the selected song
pygame.mixer.music.play()  # Play the selected song
try:
    pygame.init()
except pygame.error as e:
    print(f"Error loading music file: {music_files[i]} - {e}")

    # Update the display
pygame.display.set_mode((800, 600), 0, 8)
pygame.display.update()

# Quit pygame
pygame.quit()